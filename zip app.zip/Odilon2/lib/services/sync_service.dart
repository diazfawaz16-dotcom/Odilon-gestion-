import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/produit.dart';
import '../models/depot.dart';
import '../models/vente.dart';
import '../models/historique.dart';
import 'google_drive_service.dart';

class SyncService {
  final GoogleDriveService driveService;

  SyncService({required this.driveService});

  Future<List<Produit>> loadProduits() async {
    String jsonString = await driveService.readFile('produits.json');
    final data = json.decode(jsonString);
    return (data['produits'] as List)
        .map((p) => Produit.fromJson(p))
        .toList();
  }

  Future<List<Depot>> loadDepots() async {
    String jsonString = await driveService.readFile('depots.json');
    final data = json.decode(jsonString);
    return (data['depots'] as List).map((d) => Depot.fromJson(d)).toList();
  }

  Future<void> saveProduits(List<Produit> produits) async {
    final data = {'produits': produits.map((p) => p.toJson()).toList()};
    await driveService.writeFile('produits.json', json.encode(data));
  }

  Future<void> saveDepots(List<Depot> depots) async {
    final data = {'depots': depots.map((d) => d.toJson()).toList()};
    await driveService.writeFile('depots.json', json.encode(data));
  }

  // Ajouter méthodes pour ventes et historique de la même façon
}