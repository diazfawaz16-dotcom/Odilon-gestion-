import 'dart:convert';
import 'package:http/http.dart' as http;

class GoogleDriveService {
  Map<String, dynamic> localData = {};

  // Authentification simple
  Future<bool> authenticate(String username, String password) async {
    if ((username == 'odilon' && password == 'admin123') ||
        (username == 'gerant' && password == 'gerant123')) {
      return true;
    }
    return false;
  }

  String getUserRole(String username) {
    return username == 'odilon' ? 'admin' : 'gerant';
  }

  Future<Map<String, dynamic>> loadData() async {
    // TODO: charger le fichier JSON depuis Google Drive
    return localData;
  }

  Future<void> saveData(Map<String, dynamic> data) async {
    // TODO: sauvegarder sur Google Drive
    localData = data;
  }
}