import 'package:flutter/material.dart';
import '../services/google_drive_service.dart';
import 'admin_dashboard.dart';
import 'gerant_dashboard.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void login(BuildContext context) async {
    final username = usernameController.text;
    final password = passwordController.text;

    bool success = await GoogleDriveService().authenticate(username, password);
    if (!success) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Identifiants invalides')));
      return;
    }

    String role = GoogleDriveService().getUserRole(username);
    if (role == 'admin') {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => AdminDashboard()));
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => GerantDashboard()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
                controller: usernameController,
                decoration: InputDecoration(labelText: 'Username')),
            TextField(
                controller: passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(
                onPressed: () => login(context), child: Text('Se connecter'))
          ],
        ),
      ),
    );
  }
}