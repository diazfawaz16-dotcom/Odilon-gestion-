import 'package:flutter/material.dart';
import '../models/produit.dart';
import '../models/depot.dart';
import '../services/sync_service.dart';
import '../services/google_drive_service.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  late SyncService syncService;
  List<Produit> produits = [];
  List<Depot> depots = [];

  @override
  void initState() {
    super.initState();
    syncService = SyncService(driveService: GoogleDriveService());
    loadData();
  }

  Future<void> loadData() async {
    final loadedProduits = await syncService.loadProduits();
    final loadedDepots = await syncService.loadDepots();
    setState(() {
      produits = loadedProduits;
      depots = loadedDepots;
    });
  }

  void addProduit() {
    // Exemple simple : ajouter un produit fictif
    Produit nouveau = Produit(
        designation: "Nouveau Produit",
        prixCasier: 100000,
        unitesParCasier: 24,
        prixUnite: 4167);
    setState(() {
      produits.add(nouveau);
    });
    syncService.saveProduits(produits);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: loadData,
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: produits.length,
              itemBuilder: (context, index) {
                final p = produits[index];
                return ListTile(
                  title: Text(p.designation),
                  subtitle: Text(
                      "Casier: ${p.prixCasier} GNF | Unité: ${p.prixUnite} GNF"),
                );
              },
            ),
          ),
          ElevatedButton(onPressed: addProduit, child: Text('Ajouter Produit'))
        ],
      ),
    );
  }
}