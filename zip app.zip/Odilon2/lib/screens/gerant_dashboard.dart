import 'package:flutter/material.dart';
import '../models/produit.dart';
import '../models/depot.dart';
import '../models/vente.dart';
import '../services/sync_service.dart';
import '../services/google_drive_service.dart';

class GerantDashboard extends StatefulWidget {
  @override
  _GerantDashboardState createState() => _GerantDashboardState();
}

class _GerantDashboardState extends State<GerantDashboard> {
  late SyncService syncService;
  List<Produit> produits = [];
  List<Depot> depots = [];
  List<Vente> ventes = [];

  Produit? selectedProduit;
  Depot? selectedDepot;
  final quantiteController = TextEditingController();

  @override
  void initState() {
    super.initState();
    syncService = SyncService(driveService: GoogleDriveService());
    loadData();
  }

  Future<void> loadData() async {
    final loadedProduits = await syncService.loadProduits();
    final loadedDepots = await syncService.loadDepots();
    setState(() {
      produits = loadedProduits;
      depots = loadedDepots;
    });
  }

  void addVente() {
    if (selectedProduit != null && selectedDepot != null && quantiteController.text.isNotEmpty) {
      int qty = int.parse(quantiteController.text);
      Vente v = Vente(
        produit: selectedProduit!.designation,
        depot: selectedDepot!.nom,
        quantite: qty,
        date: DateTime.now(),
      );
      setState(() {
        ventes.add(v);
      });
      // Ici tu peux créer une fonction dans SyncService pour sauvegarder les ventes
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gérant Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: loadData,
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButton<Produit>(
              hint: Text('Sélectionner Produit'),
              value: selectedProduit,
              items: produits.map((p) => DropdownMenuItem(
                child: Text(p.designation),
                value: p,
              )).toList(),
              onChanged: (val) => setState(() => selectedProduit = val),
            ),
            DropdownButton<Depot>(
              hint: Text('Sélectionner Dépôt'),
              value: selectedDepot,
              items: depots.map((d) => DropdownMenuItem(
                child: Text(d.nom),
                value: d,
              )).toList(),
              onChanged: (val) => setState(() => selectedDepot = val),
            ),
            TextField(
              controller: quantiteController,
              decoration: InputDecoration(labelText: 'Quantité vendue'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: addVente, child: Text('Enregistrer Vente')),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: ventes.length,
                itemBuilder: (context, index) {
                  final v = ventes[index];
                  return ListTile(
                    title: Text('${v.produit} - ${v.depot}'),
                    subtitle: Text('Quantité: ${v.quantite} | Date: ${v.date}'),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}