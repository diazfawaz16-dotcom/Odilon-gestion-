class Constants {
  // Identifiants par défaut
  static const String adminUser = 'admin';
  static const String adminPass = 'admin123';
  
  static const String gerantUser = 'gerant';
  static const String gerantPass = 'gerant123';

  // Paramètres de synchronisation
  static const int syncIntervalSeconds = 30; // toutes les 30 secondes

  // Noms des fichiers JSON
  static const String produitsFile = 'produits.json';
  static const String depotsFile = 'depots.json';
  static const String ventesFile = 'ventes.json';
  static const String historiqueFile = 'historique.json';
}