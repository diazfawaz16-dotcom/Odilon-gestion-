class Depot {
  String nom;

  Depot({required this.nom});

  factory Depot.fromJson(Map<String, dynamic> json) {
    return Depot(nom: json['nom']);
  }

  Map<String, dynamic> toJson() {
    return {'nom': nom};
  }
}