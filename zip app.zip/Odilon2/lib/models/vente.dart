class Vente {
  String produit;
  String depot;
  int quantite;
  DateTime date;

  Vente({
    required this.produit,
    required this.depot,
    required this.quantite,
    required this.date,
  });

  factory Vente.fromJson(Map<String, dynamic> json) {
    return Vente(
      produit: json['produit'],
      depot: json['depot'],
      quantite: json['quantite'],
      date: DateTime.parse(json['date']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'produit': produit,
      'depot': depot,
      'quantite': quantite,
      'date': date.toIso8601String(),
    };
  }
}