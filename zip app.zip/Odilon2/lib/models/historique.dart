class Historique {
  String action;
  String utilisateur;
  DateTime date;
  String details;

  Historique({
    required this.action,
    required this.utilisateur,
    required this.date,
    required this.details,
  });

  factory Historique.fromJson(Map<String, dynamic> json) {
    return Historique(
      action: json['action'],
      utilisateur: json['utilisateur'],
      date: DateTime.parse(json['date']),
      details: json['details'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'action': action,
      'utilisateur': utilisateur,
      'date': date.toIso8601String(),
      'details': details,
    };
  }
}