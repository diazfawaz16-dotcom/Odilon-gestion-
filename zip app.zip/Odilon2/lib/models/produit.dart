class Produit {
  String designation;
  int prixCasier;
  int unitesParCasier;
  int prixUnite;

  Produit({
    required this.designation,
    required this.prixCasier,
    required this.unitesParCasier,
    required this.prixUnite,
  });

  factory Produit.fromJson(Map<String, dynamic> json) {
    return Produit(
      designation: json['designation'],
      prixCasier: json['prixCasier'],
      unitesParCasier: json['unitesParCasier'],
      prixUnite: json['prixUnite'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'designation': designation,
      'prixCasier': prixCasier,
      'unitesParCasier': unitesParCasier,
      'prixUnite': prixUnite,
    };
  }
}